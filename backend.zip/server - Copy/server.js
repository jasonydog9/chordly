const verifyFirebaseToken = require('./middleware/auth');
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./db/conn');
const User = require('./models/User');
const serverless = require("serverless-http");

const app = express();

// Global database connection cache
let cachedDb = null;

// CORS configuration
app.use(cors({
  origin: ['http://localhost:3000', 'https://your-frontend-domain.com', '*'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Add request logging middleware
app.use((req, res, next) => {
  console.log(`📍 ${req.method} ${req.path} - ${new Date().toISOString()}`);
  next();
});

// Database connection middleware
app.use(async (req, res, next) => {
  try {
    if (!cachedDb) {
      console.log("🌐 Connecting to MongoDB...");
      await connectDB();
      cachedDb = true;
      console.log("✅ Connected to MongoDB");
    }
    next();
  } catch (error) {
    console.error('❌ Database connection error:', error);
    res.status(500).json({ error: 'Database connection failed' });
  }
});

// Load routes
console.log('🔍 Loading routes...');

try {
  console.log('🔍 Loading user routes...');
  const userRoutes = require('./routes/userRoutes');
  app.use('/api/users', userRoutes);
  console.log('✅ User routes loaded successfully');
} catch (error) {
  console.error('❌ Error loading user routes:', error);
}

try {
  console.log('🔍 Loading chord routes...');
  const chordRoutes = require('./routes/chordRoutes');
  app.use('/api/chords', chordRoutes);
  console.log('✅ Chord routes loaded successfully');
} catch (error) {
  console.error('❌ Error loading chord routes:', error);
}

// Basic routes
app.get("/", (req, res) => {
  console.log("✅ Root hit");
  res.json({ 
    message: "✅ Lambda root works!",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

app.get("/api/hello", (req, res) => {
  console.log("✅ /api/hello route hit");
  try {
    res.json({ 
      message: "Hello from Lambda!",
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error("❌ Error in /api/hello:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    database: cachedDb ? 'connected' : 'disconnected'
  });
});

// Login handler
app.post('/api/login', verifyFirebaseToken, async (req, res) => {
  try {
    const { uid, email, name, picture } = req.user;
    console.log('🔐 Login attempt for:', email);

    let user = await User.findOne({ uid });

    if (!user) {
      user = await User.create({
        uid,
        email,
        displayName: name,
        photoURL: picture
      });
      console.log('🆕 New user created:', email);
    } else {
      console.log('👤 Existing user found:', email);
    }

    res.json({ message: 'User authenticated', user });
  } catch (err) {
    console.error('❌ Error in login:', err);
    res.status(500).json({ error: 'Authentication failed' });
  }
});

// REMOVED THE DUPLICATE ROUTE - this was causing the conflict!
// The /api/users/:username route should be handled in userRoutes.js instead

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// 404 handler
app.use('*', (req, res) => {
  console.log('❌ 404 - Route not found:', req.method, req.originalUrl);
  res.status(404).json({
    error: 'Route not found',
    path: req.originalUrl,
    method: req.method
  });
});

// Lambda handler
const handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  try {
    console.log('🚀 Lambda handler invoked successfully');
    return await serverless(app)(event, context);
  } catch (error) {
    console.error('❌ Lambda handler error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        error: 'Lambda execution failed',
        message: error.message,
        requestId: context.awsRequestId
      })
    };
  }
};

module.exports.handler = handler;